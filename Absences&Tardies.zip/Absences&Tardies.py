
#storage for tracking what's left
absences=4
tardies=5

a_days=int(input("how many periods do you have in an a day? "))

for i in range(1,a_days+1):
    classperiod=input("did you attend " +" period "+str(i)+"?(y/n) ")
    if classperiod=="n":
        absences-=1
        print("You have " + str(absences) + " absences left in class period " +str(i))
    if classperiod == "y":
        on_time=(input("were you late?(y/n) "))
        if on_time=="y":
            tardies-=1
        print("You have " + str(absences) + " absences left and "  + str(tardies)+ " tardies left "+"in class period " +str(i))

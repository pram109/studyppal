#this program takes user input in the form of a date entered and
#calculates the number of days left before that is due
#https://youtu.be/Nbh0KXHEDUo <-- reference video 
#create counters

import time
from datetime import datetime
import tkinter as tk
from tkcalendar import Calendar

def updateLabel(event):
    # get the selected date string 
    date_str = calendar.get_date()
    due_date = datetime.strptime(date_str, "%m/%d/%y").date()
    
    #get today date
    today = datetime.today().date()
    #days left
    days_left = (due_date - today).days
    #cases
    if days_left > 1:
        label.config(text=f"Due Date: {due_date}  -->  Days Left: {days_left}")
    elif days_left == 1: 
        label.config(text=f"Due Date: {due_date}  -->  It's due TOMORROW!")
    else:
        label.config(text=f"Due Date: {due_date}  -->  It's due TODAY!!!!!!")

root = tk.Tk()

calendar = Calendar(root, min_date = datetime(2025, 9, 23), max_date = datetime(2025, 12, 30), 
                    showweeknumbers = False, showothermonthdays = False)

#Website Hexcodes: CCD5AE - -E9EDC9 - FEFAE0 - FAEDCD - D4A373

#widget
calendar.pack()
calendar.bind("<<CalendarSelected>>", updateLabel)

#labels 
label = tk.Label(root, text = "Date Due: ")
label.pack()

#calculate days left 
#store the selected date in a var



root.mainloop()


def my_function():
   print("Checklist:")
   print("1. Add task")
   print("2. Remove task")
   taskList = []
   while True:
    userInput = input("Choose an option (1, 2, or 'exit' to quit): ")

   #user wants to add task
    if userInput == "1":
         task = input("Enter the task: ")
         taskList.append(task)
         print("Checklist:",taskList)

   #user wants to remove task
    elif userInput == "2":
            task = input("Enter the task to remove: ")
            if task in taskList:
                taskList.remove(task)
                print("Checklist:",taskList)
            else:
                print("Task not found.")

   #user wants to exit checklist 
    elif userInput == "exit":
        print("Exiting...")
        break  

    else:
        print("Invalid input. Please choose 1, 2, or 'exit'.")  

my_function()
        
